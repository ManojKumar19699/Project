export class InsuranceClaim 
{
  public AmountClaimed:number;
  public DateOfClaim:string;
  public DateOfLoss:string;
  public CauseOfClaim:string;
  public PolicyNo:number;
}