export class AuctionBid{
    BidPrice:number;
}
