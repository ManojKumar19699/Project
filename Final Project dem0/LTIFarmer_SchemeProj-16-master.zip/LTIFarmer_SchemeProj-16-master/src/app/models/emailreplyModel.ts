export class EmailReply{
    To:string;
    From:string;
    Subject:string;
    Body:string;
}