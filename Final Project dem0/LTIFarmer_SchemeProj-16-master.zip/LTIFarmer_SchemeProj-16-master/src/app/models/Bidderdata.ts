export class BidderData{
    BidderName:String;
	BidderEmail:String;
	BidderContactNo:String;
    BidderAddress:String;
    BidderCity:string;
    BidderState:String;
    BidderPincocde:String;
    BidderAadhar:String;
    BidderTradeLicense:String;
    BidderPassword:String;
    BidderConfirmPassword:String;
    
    AccountNo:String;
    IFSC_Code:String;
}