export class SaleHistory{
    Farmerid?:number;
    Bidderid?:number;
    CropName:string;
    Quantity?:number;
    MinSalePrice?:number;
    Price?:number;
    ApprovalAdminId?:number;
}