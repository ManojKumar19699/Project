export class Contactus{
    Email:string;
    ContactName:string;
    RequestType:string;
    Message:string;
    Status:string;
    ApprovalAdminId?:number;
}