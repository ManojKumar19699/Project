export class CropRequestModel
{   
        public CropType:string;
        public CropName:string;
        public FertilizerType:string;
        public SoilPhCertificate:string;
        public Quantity:number;

}