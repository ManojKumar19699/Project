export class FarmerMarketPlaceModel 
{
    
}