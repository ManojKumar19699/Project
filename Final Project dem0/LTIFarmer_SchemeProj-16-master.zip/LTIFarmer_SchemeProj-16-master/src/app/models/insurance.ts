export class InsuranceApp{
    CompanyName: string;
    Season: string;
    Year: string;
    CropName:string;
    SumAssured: number;
    //DateOfInsurance: string;
    SumAssuredPerHec:number;
    Area:number;
    Premium:number;
    Farmerid:string;
}