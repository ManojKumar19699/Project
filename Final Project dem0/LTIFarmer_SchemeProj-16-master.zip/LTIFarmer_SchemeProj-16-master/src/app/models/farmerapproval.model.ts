export class FarmerApproval{
    Farmerid: number;
    FarmerName:String;
    FarmerContactNo:String;
	FarmerEmail:String;
    FarmerAddress:String;
    FarmerCity:string;
    FarmerState:String;
    FarmerPincocde:String;
    FarmerAadhar:String;
    FarmerCertificate:String;
    FarmerPassword:String;
    FarmerApproved:boolean;
    ApprovalAdminId:number;
}


