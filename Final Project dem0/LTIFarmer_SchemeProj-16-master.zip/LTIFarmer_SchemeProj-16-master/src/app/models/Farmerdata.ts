export class Farmerdata{
    FarmerName:String;
	FarmerEmail:String;
	FarmerContactNo:String;
    FarmerAddress:String;
    FarmerCity:string;
    FarmerState:String;
    FarmerPincocde:String;
    FarmerAadhar:String;
    FarmerCertificate:String;
    FarmerPassword:String;
    FarmerConfirmPassword:String;

    FarmerLandArea:String;
	FarmerLandAddress:String;
    FarmerLandPincode:String;

    AccountNo:String;
    IFSC_Code:String;
}