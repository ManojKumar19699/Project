export class BidderApproval{
    Bidderid: number;
    BidderName:String;
    BidderContactNo:String;
	BidderEmail:String;
    BidderAddress:String;
    BidderCity:string;
    BidderState:String;
    BidderPincocde:String;
    BidderAadhar:String;
    BidderTradeLicense:String;
    BidderPassword:String;
    BidderApproved:boolean;
    ApprovalAdminId:number;
}
