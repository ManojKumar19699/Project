import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-faq',
  templateUrl: './home-faq.component.html',
  styleUrls: ['./home-faq.component.css']
})
export class HomeFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
